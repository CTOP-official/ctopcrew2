require 'spreadsheet'
require 'roo'
require 'mysql2'

db = Mysql2::Client.new(host: 'localhost', username: 'ctop', password: '0815', database: 'ctop')
xlsx = Roo::Spreadsheet.open('./abcde.xlsx')
sheet = xlsx.sheet(0)
mm = Hash.new
sheet.column(2).each_with_index do |i, index|
    if index > 1
        date2 = sheet.row(index+1)[0].to_s
        code = sheet.row(index+1)[-1]
        songjang = sheet.row(index+1)[4]
        dome = sheet.row(index+1)[5]
        mm[code] = [date2, songjang, dome]
    end
end

file_name = Dir.entries("./")
file_name.delete('.')
file_name.delete('..')
file_name.delete('main.rb')
file_name.delete('abcde.xlsx')

p file_name

file_name.each do |i|
    workbook = Spreadsheet.open i
    worksheets = workbook.worksheets

    date = i.split('_')[2].split('(')[0]

    worksheets[0].rows.each_with_index do |row,index|
        if index > 0
            row2 = row.to_a
            p row2
            dd = Hash.new
            dd['date1'] = date
            begin
                dd['date2'] = mm[row2[9]][0]
            rescue
                dd['date2'] = '2024-06-17'
            end
            dd['date3'] = '2024-06-17'
            dd['name1'] = row2[2].split('-')[0]
            dd['market1'] = row2[2].split('-')[1]
            dd['date4'] = '2024-06-17'
            begin
                dd['deliNo'] = mm[row2[9]][1]
                dd['code1'] = mm[row2[9]][2]
            rescue
                dd['deliNo'] = '??'
                dd['code1'] = '??'
            end
            dd['unicode'] = row2[9]
            dd['code2'] = row2[10]
            dd['procode'] = row2[1]
            dd['barcode'] = ''
            dd['con1'] = ''
            dd['optcon'] = '1'
            dd['ordName'] = row2[12]
            dd['ordTel'] = row2[18]
            dd['getName'] = row2[12]
            dd['getTel'] = row2[19]
            dd['pnum'] = row2[14]
            dd['enum'] = row2[15]
            dd['home'] = row2[16]
            dd['messege'] = row2[17]
            dd['che1'] = ''
            dd['moneyNum'] = ''
            dd['money1'] = ''
            dd['money2'] = ''
            dd['money3'] = ''
            dd['money4'] = ''
            dd['moneyDate'] = ''
            dd['money5'] = ''
            dd['money6'] = ''
            dd['productName'] = row2[21]
            dd['api_result'] = '정상(주문자)'
            dd['download1'] = '2024-06-17'
            dd['download2'] = '2024-06-17'
            dd['bin1'] = '2024-06-17'
            dd['bin2'] = ''
            dd['bin3'] = ''

            vv = dd.values.map do |kk|
                '"'+kk.to_s.split('"').join('')+'"'
            end

            q = 'insert into CTOPORDER('+dd.keys.join(',')+') values('+vv.join(',')+')'
            puts q
            db.query(q)
        end
    end
end