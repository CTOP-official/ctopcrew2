#!/bin/bash

ruby ./start.rb;